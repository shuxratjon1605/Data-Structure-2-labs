"""Part E. Run twice per case, keep the second measurement.

Source: Week3_Lab_Handout.docx.
Run: python benchmark.py
"""
import bisect
import csv
import json
import math
from pathlib import Path
import platform
import random
import time

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from week3_lab import BST, AVLTree
from rbtree import RBTree

SEED = 20261010
HERE = Path(__file__).resolve().parent

class SortedList:
    def __init__(self):
        self.keys = []

    def insert(self, key):
        i = bisect.bisect_left(self.keys, key)
        if i == len(self.keys) or self.keys[i] != key:
            bisect.insort(self.keys, key)

    def search(self, key):
        i = bisect.bisect_left(self.keys, key)
        return i < len(self.keys) and self.keys[i] == key

    def height(self):
        return None

def run(cls, keys):
    """Return (insert milliseconds, 1,000 searches milliseconds, height)."""
    structure = cls()
    start = time.perf_counter()
    for key in keys:
        structure.insert(key)
    insert_ms = (time.perf_counter() - start) * 1000
    probe = random.sample(keys, 1000)  # Outside the timed interval.
    start = time.perf_counter()
    found = 0
    for key in probe:
        found += structure.search(key)
    search_ms = (time.perf_counter() - start) * 1000
    assert found == len(probe)
    if hasattr(structure, 'is_valid'):
        assert structure.is_valid()
    return insert_ms, search_ms, structure.height()

def main():
    structures = [('Plain BST', BST), ('AVL tree', AVLTree),
                  ('Red-Black tree', RBTree), ('Sorted list + bisect', SortedList)]
    rows = []
    for n in (1000, 2000, 4000, 8000):
        for order in ('random', 'sorted'):
            keys = list(range(n))
            if order == 'random':
                random.Random(SEED + n).shuffle(keys)
            for label, cls in structures:
                for repeat in range(2):
                    # Same successful probes for every structure, both runs.
                    random.seed(SEED + n + (order == 'sorted'))
                    values = run(cls, keys)
                row = dict(n=n, order=order, structure=label,
                           insert_ms=values[0], search_ms=values[1], height=values[2])
                rows.append(row)
                print(f'{n:5d} {order:6s} {label:20s} '
                      f'build={values[0]:9.3f} ms search={values[1]:8.3f} ms h={values[2]}')
    with (HERE/'benchmark_results.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    payload = dict(seed=SEED, repetitions=2, retained_run=2,
                   python=platform.python_version(), implementation=platform.python_implementation(),
                   system=platform.system(), machine=platform.machine(),
                   timer='time.perf_counter', rows=rows)
    (HERE/'benchmark_results.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    colors = ['#165D9C', '#187C67', '#B65E17']
    for order in ('random', 'sorted'):
        fig, ax = plt.subplots(figsize=(8, 4.8), layout='constrained')
        for (label, _), color in zip(structures[:3], colors):
            selected = [r for r in rows if r['order'] == order and r['structure'] == label]
            ax.plot([r['n'] for r in selected], [r['height'] for r in selected],
                    marker='o', label=label, color=color, linewidth=2)
        if order == 'random':
            ns = [1000, 2000, 4000, 8000]
            ax.plot(ns, [math.log2(n) for n in ns], '--', color='#60656B', label='log2(n)')
        else:
            ax.set_yscale('log')
        ax.set(xlabel='Number of keys n', ylabel='Height in edges',
               title=f'Tree height with {order} insertion order')
        ax.grid(True, alpha=.25)
        ax.legend()
        fig.savefig(HERE/f'height_{order}.png', dpi=180)
        plt.close(fig)

if __name__ == '__main__':
    main()
