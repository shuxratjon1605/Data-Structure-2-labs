# Source: supplied lab handout and its starter code.
"""Week 3 Lab - Advanced Trees.
 
Run this file to test the implementation:
    python week3_lab.py
The original test functions are included below.
"""
import bisect
import random
import sys
import time
 
sys.setrecursionlimit(10000)
 
 
# ======================================================== Part A: plain BST
class BSTNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
 
 
class BST:
    def __init__(self):
        self.root = None
 
    def insert(self, key):
        """A1: iterative insertion (no recursion). Ignore duplicates."""
        if self.root is None:
            self.root = BSTNode(key)
            return
        cur = self.root
        while True:
            if key < cur.key:
                if cur.left is None:
                    cur.left = BSTNode(key)
                    return
                cur = cur.left
            elif key > cur.key:
                if cur.right is None:
                    cur.right = BSTNode(key)
                    return
                cur = cur.right
            else:
                return
 
    def search(self, key):
        """A2: iterative search. Return True if key is present."""
        cur = self.root
        while cur is not None:
            if key == cur.key:
                return True
            cur = cur.left if key < cur.key else cur.right
        return False
 
    def height(self):
        """A3: height in edges (empty tree = -1). Must work for a
        7,999-level chain, so use an explicit stack or queue, not recursion."""
        if self.root is None:
            return -1
        stack = [(self.root, 0)]
        answer = 0
        while stack:
            node, depth = stack.pop()
            answer = max(answer, depth)
            if node.left is not None:
                stack.append((node.left, depth + 1))
            if node.right is not None:
                stack.append((node.right, depth + 1))
        return answer
 
 
# ======================================================== Part B: rotations
def rotate_left(x):
    """B1: rotate left at x and return the new subtree root."""
    if x is None or x.right is None:
        raise ValueError('left rotation requires a right child')
    y = x.right
    x.right = y.left
    y.left = x
    return y
 
 
def rotate_right(y):
    """B2: rotate right at y and return the new subtree root."""
    if y is None or y.left is None:
        raise ValueError('right rotation requires a left child')
    x = y.left
    y.left = x.right
    x.right = y
    return x
 
 
# ======================================================== Part C: AVL tree
class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 0
 
 
def h(node):
    return node.height if node else -1
 
 
def update(node):
    node.height = 1 + max(h(node.left), h(node.right))
 
 
def balance(node):
    return h(node.left) - h(node.right)
 
 
class AVLTree:
    def __init__(self):
        self.root = None
        self.rotations = 0
 
    def rotate_left(self, x):
        """C1: as rotate_left above, plus update heights (lower node first)
        and add 1 to self.rotations."""
        y = rotate_left(x)
        update(x)  # Update the lower node before its new parent.
        update(y)
        self.rotations += 1
        return y
 
    def rotate_right(self, y):
        """C2: mirror of rotate_left."""
        x = rotate_right(y)
        update(y)
        update(x)
        self.rotations += 1
        return x
 
    def rebalance(self, node):
        """C3: update node's height; if |BF| > 1 apply the LL, LR, RR
        or RL fix; return the (possibly new) subtree root."""
        update(node)
        bf = balance(node)  # Left height minus right height.
        if bf > 1:
            if balance(node.left) < 0:  # LR: first turn the triangle into a line.
                node.left = self.rotate_left(node.left)
            return self.rotate_right(node)  # LL (also child BF = 0).
        if bf < -1:
            if balance(node.right) > 0:  # RL.
                node.right = self.rotate_right(node.right)
            return self.rotate_left(node)  # RR (also child BF = 0).
        return node
 
    def insert(self, key):
        self.root = self._insert(self.root, key)
 
    def _insert(self, node, key):
        """C4: recursive BST insertion that returns self.rebalance(node)."""
        if node is None:
            return AVLNode(key)
        if key < node.key:
            node.left = self._insert(node.left, key)
        elif key > node.key:
            node.right = self._insert(node.right, key)
        else:
            return node  # Ignore duplicate keys.
        return self.rebalance(node)
 
    def search(self, key):
        cur = self.root
        while cur:
            if key == cur.key:
                return True
            cur = cur.left if key < cur.key else cur.right
        return False
 
    def height(self):
        return h(self.root)
 
    def is_valid(self):
        """C5: return True only if (1) BST order holds, (2) every stored
        height is correct and (3) every balance factor is -1, 0 or +1."""
        seen = set()
        def check(node, lo, hi):
            if node is None:
                return -1
            if id(node) in seen:
                raise AssertionError('cycle or shared subtree')
            seen.add(id(node))
            if ((lo is not None and node.key <= lo) or
                    (hi is not None and node.key >= hi)):
                raise AssertionError('BST order is broken')
            lh = check(node.left, lo, node.key)
            rh = check(node.right, node.key, hi)
            actual_height = 1 + max(lh, rh)
            if node.height != actual_height:
                raise AssertionError('incorrect stored height')
            if abs(lh - rh) > 1:
                raise AssertionError('balance factor is outside [-1, 1]')
            return actual_height
        try:
            check(self.root, None, None)
            return True
        except AssertionError:
            return False
 
 
# ======================================================== Part D: Red-Black validator
# A Red-Black tree is given as nested tuples: (key, colour, left, right)
# where colour is "R" or "B" and an empty child (NIL) is None.
def is_valid_rb(t):
    """D3: return (True, black_height) for a valid Red-Black tree and
    (False, reason) otherwise. Check BST order and properties 2, 4 and 5.
    black_height counts the black nodes on any root-to-NIL path,
    including the root and the NIL itself."""
    if t is None:
        return True, 1  # The NIL leaf itself is black.
    if t[1] != 'B':
        return False, 'property 2: the root must be black'
    def check(node, lo, hi):
        if node is None:
            return 1
        key, colour, left, right = node
        if colour not in ('R', 'B'):
            raise AssertionError(f'property 1: invalid colour at {key}')
        if ((lo is not None and key <= lo) or
                (hi is not None and key >= hi)):
            raise AssertionError(f'BST order is broken at {key}')
        if colour == 'R' and ((left is not None and left[1] == 'R') or
                              (right is not None and right[1] == 'R')):
            raise AssertionError(f'property 4: red node {key} has a red child')
        lb = check(left, lo, key)
        rb = check(right, key, hi)
        if lb != rb:
            raise AssertionError(f'property 5: unequal black heights at {key}')
        return lb + (colour == 'B')
    try:
        return True, check(t, None, None)
    except AssertionError as exc:
        return False, str(exc)
 
 
# ======================================================== tests (do not edit)
def run(name, fn):
    try:
        fn()
        print(f"PASS  {name}")
    except NotImplementedError:
        print(f"TODO  {name}")
    except AssertionError as e:
        print(f"FAIL  {name}  {e}")
 
 
def inorder(n, out):
    if n:
        inorder(n.left, out)
        out.append(n.key)
        inorder(n.right, out)
    return out
 
 
def test_bst():
    t = BST()
    for k in range(2000):
        t.insert(k)
    assert t.height() == 1999, "sorted input should give a chain"
    assert t.search(1234) and not t.search(5000)
 
 
def test_rotations():
    rng = random.Random(0)
    for _ in range(100):
        t = BST()
        for k in rng.sample(range(500), 40):
            t.insert(k)
        before = inorder(t.root, [])
        t.root = rotate_left(t.root) if t.root.right else rotate_right(t.root)
        assert inorder(t.root, []) == before, "rotation changed the in-order sequence"
 
 
def test_avl():
    rng = random.Random(1)
    for order in ("sorted", "random"):
        keys = list(range(3000))
        if order == "random":
            rng.shuffle(keys)
        t = AVLTree()
        for k in keys:
            t.insert(k)
        assert t.is_valid(), f"invalid AVL tree ({order} input)"
        assert t.height() <= 1.44 * 11.56 + 1, "AVL tree too tall"
 
 
def test_rb():
    good = (13, "B", (8, "R", (1, "B", None, None), (11, "B", None, None)),
            (17, "R", (15, "B", None, None), (25, "B", None, None)))
    red_red = (20, "B", (10, "B", None, None), (30, "B", (25, "R", None, (27, "R", None, None)), None))
    assert is_valid_rb(good) == (True, 3), "tree 1 is valid with black-height 3 (counting NIL)"
    assert is_valid_rb(red_red)[0] is False, "tree 2 has a red node with a red child"
 
 
if __name__ == "__main__":
    run("Part A  BST on 2,000 sorted keys", test_bst)
    run("Part B  rotations keep in-order", test_rotations)
    run("Part C  AVL insert + validator", test_avl)
    run("Part D  Red-Black validator", test_rb)
