"""Part E: identical keys and probes for all seven structures.

Source: Week3B_Lab_Handout.docx.
Run: python benchmark.py
"""
import bisect
import csv
import json
from pathlib import Path
import platform
import random
import time

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from lab3b import BTree
from rbtree import RBTree

SEED = 20261010
HERE = Path(__file__).resolve().parent

class SortedList:
    def __init__(self):
        self.keys = []

    def insert(self, key):
        i = bisect.bisect_left(self.keys, key)
        if i == len(self.keys) or self.keys[i] != key:
            bisect.insort(self.keys, key)

    def search(self, key):
        i = bisect.bisect_left(self.keys, key)
        return i < len(self.keys) and self.keys[i] == key

    def height(self):
        return None

def run(make, keys, probe):
    """Return build seconds, microseconds/search, reads/search and height."""
    structure = make()
    start = time.perf_counter()
    for key in keys:
        structure.insert(key)
    build_s = time.perf_counter() - start
    if isinstance(structure, BTree):
        structure.reads = 0
    start = time.perf_counter()
    found = 0
    for key in probe:
        found += structure.search(key)
    elapsed = time.perf_counter() - start
    assert found == len(probe)
    search_us = elapsed * 1_000_000 / len(probe)
    reads_per_search = structure.reads / len(probe) if isinstance(structure, BTree) else None
    if hasattr(structure, 'is_valid'):
        assert structure.is_valid()
    return build_s, search_us, reads_per_search, structure.height()

def main():
    rng = random.Random(SEED)
    keys = list(range(100000))
    rng.shuffle(keys)
    probe = rng.sample(keys, 5000)
    structures = [(f'B-tree t = {t}', lambda t=t: BTree(t), t) for t in (2, 4, 16, 64, 256)]
    structures.extend([('Red-Black tree', RBTree, None), ('Sorted list + bisect', SortedList, None)])
    rows = []
    for label, make, degree in structures:
        for repeat in range(2):
            build_s, search_us, reads, height = run(make, keys, probe)
        rows.append(dict(structure=label, t=degree, build_s=build_s,
                         search_us=search_us, reads_per_search=reads, height=height))
        print(f'{label:22s} build={build_s:8.4f} s search={search_us:7.3f} us '
              f'reads={reads} h={height}')
    with (HERE/'benchmark_results.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    payload = dict(seed=SEED, n=len(keys), probes=len(probe), repetitions=2,
                   retained_run=2, python=platform.python_version(),
                   implementation=platform.python_implementation(),
                   system=platform.system(), machine=platform.machine(),
                   timer='time.perf_counter', rows=rows)
    (HERE/'benchmark_results.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    tree_rows = rows[:5]
    degrees = [r['t'] for r in tree_rows]
    fig, ax = plt.subplots(figsize=(8, 4.8), layout='constrained')
    ax.plot(degrees, [r['height'] for r in tree_rows], 'o-', color='#165D9C',
            linewidth=2, label='B-tree')
    ax.axhline(rows[5]['height'], linestyle='--', color='#B65E17', label='Red-Black tree')
    ax.set_xscale('log', base=2)
    ax.set_xticks(degrees, [str(t) for t in degrees])
    ax.set(xlabel='Minimum degree t', ylabel='Height in edges',
           title='Height of indexes over 100,000 random-order keys')
    ax.grid(True, alpha=.25)
    ax.legend()
    fig.savefig(HERE/'height_vs_t.png', dpi=180)
    plt.close(fig)
    fig, left = plt.subplots(figsize=(8, 4.8), layout='constrained')
    right = left.twinx()
    a, = left.plot(degrees, [r['reads_per_search'] for r in tree_rows], 'o-',
                   color='#165D9C', label='Average page reads', linewidth=2)
    b, = right.plot(degrees, [r['search_us'] for r in tree_rows], 's-',
                    color='#B65E17', label='Microseconds per search', linewidth=2)
    left.set_xscale('log', base=2)
    left.set_xticks(degrees, [str(t) for t in degrees])
    left.set(xlabel='Minimum degree t', ylabel='Page reads per successful search',
             title='Page visits and measured search time')
    right.set_ylabel('Microseconds per successful search')
    left.grid(True, alpha=.25)
    left.legend(handles=[a, b], loc='upper right')
    fig.savefig(HERE/'reads_and_time_vs_t.png', dpi=180)
    plt.close(fig)

if __name__ == '__main__':
    main()
