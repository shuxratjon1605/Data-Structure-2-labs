"""Reproducible experiment/report generator for Lab 5.
Run this after lab5.py: python experiments.py
"""
import math, random, time, statistics, csv
from collections import Counter
import matplotlib.pyplot as plt
from lab5 import *

rng = random.Random(2026)
# B4: occupancy distribution for 10,000 keys in 10,000 buckets.
m=n=10000
t=ChainedHashTable(m, resize=False)
for k in rng.sample(range(1, 10**9), n): t.put(k, 1)
obs=Counter(t.chain_lengths())
ks=list(range(9))
observed=[obs.get(k,0) for k in ks]
expected=[m*math.exp(-1)/math.factorial(k) for k in ks]
plt.figure(figsize=(8,4.8))
x=list(range(len(ks))); w=.38
plt.bar([i-w/2 for i in x], observed, width=w, label="Observed")
plt.bar([i+w/2 for i in x], expected, width=w, label="Poisson prediction")
plt.xticks(x,ks); plt.xlabel("Chain length"); plt.ylabel("Number of buckets")
plt.title("B4: Observed chain lengths vs Poisson prediction (alpha = 1)")
plt.legend(); plt.tight_layout(); plt.savefig("B4_poisson.png", dpi=160); plt.close()

# D2: probe measurements for all schemes and theory curves.
M=1<<14
alphas=[.1,.2,.3,.4,.5,.6,.7,.8,.9,.95]
schemes=["chaining","linear","quadratic","double"]
measured_s={s:[] for s in schemes}; measured_u={s:[] for s in schemes}
theory_lin_s=[]; theory_lin_u=[]; theory_uni_s=[]; theory_uni_u=[]
theory_chain_s=[]; theory_chain_u=[]
for a in alphas:
    n=int(a*M)
    keys=rng.sample(range(1,1<<62),2*n)
    ins, absent=keys[:n],keys[n:]
    # chaining without resize, default multiplicative index
    c=ChainedHashTable(M,resize=False)
    for k in ins: c.put(k,1)
    c.probes=0
    for k in ins: c.get(k)
    measured_s["chaining"].append(c.probes/n)
    c.probes=0
    for k in absent: c.get(k)
    measured_u["chaining"].append(c.probes/n)
    for s in ("linear","quadratic","double"):
        t=OpenHashTable(M,s,resize=False,max_load=.99)
        for k in ins: t.put(k,1)
        t.probes=0
        for k in ins: t.get(k)
        measured_s[s].append(t.probes/n)
        t.probes=0
        for k in absent: t.get(k)
        measured_u[s].append(t.probes/n)
    theory_lin_s.append(.5*(1+1/(1-a)))
    theory_lin_u.append(.5*(1+1/(1-a)**2))
    theory_uni_s.append(math.log(1/(1-a))/a)
    theory_uni_u.append(1/(1-a))
    theory_chain_s.append(1+a/2)
    theory_chain_u.append(a)

# Two-panel figure; log y-axis for unsuccessful search as required.
fig,axs=plt.subplots(1,2,figsize=(13,5))
for s in schemes:
    axs[0].plot(alphas, measured_u[s], marker="o", label=s)
axs[0].plot(alphas,theory_lin_u,"k--",label="linear theory")
axs[0].plot(alphas,theory_uni_u,"k:",label="uniform hashing theory")
axs[0].plot(alphas,theory_chain_u,color="gray",linestyle="-.",label="chaining theory")
axs[0].set_yscale("log"); axs[0].set_xlabel("Load factor alpha"); axs[0].set_ylabel("Average probes")
axs[0].set_title("Unsuccessful searches"); axs[0].legend(fontsize=7)
for s in schemes:
    axs[1].plot(alphas, measured_s[s], marker="o", label=s)
axs[1].plot(alphas,theory_lin_s,"k--",label="linear theory")
axs[1].plot(alphas,theory_uni_s,"k:",label="uniform hashing theory")
axs[1].plot(alphas,theory_chain_s,color="gray",linestyle="-.",label="chaining theory")
axs[1].set_xlabel("Load factor alpha"); axs[1].set_ylabel("Average probes")
axs[1].set_title("Successful searches"); axs[1].legend(fontsize=7)
fig.suptitle("D2: Search cost vs load factor")
fig.tight_layout(); fig.savefig("D2_probes_vs_alpha.png",dpi=160); plt.close(fig)

# E2: slowest insertion per block of 500, for chaining resize.
rng2=random.Random(7)
t=ChainedHashTable(8,max_load=1.0)
block_max=[]; times=[]
for i in range(100000):
    k=rng2.randrange(1,1<<62)
    start=time.perf_counter_ns(); t.put(k,i); elapsed=time.perf_counter_ns()-start
    times.append(elapsed)
for start in range(0,len(times),500):
    block_max.append(max(times[start:start+500]))
plt.figure(figsize=(9,4.5))
plt.plot(range(500,len(times)+1,500),block_max)
plt.yscale("log"); plt.xlabel("Insertion count"); plt.ylabel("Slowest insertion in block (ns, log scale)")
plt.title("E2: Resize spikes during chained-table insertions")
plt.tight_layout(); plt.savefig("E2_resize_spikes.png",dpi=160); plt.close()

# E1/E3 deterministic run metrics
rng3=random.Random(11); t=ChainedHashTable(8,max_load=1.0)
for i in range(100000): t.put(rng3.randrange(1,1<<62),i)
e1=(t.resizes,t.moves,t.moves/100000)
M=1<<14
ot=OpenHashTable(M,"linear",resize=False,max_load=.99)
initial=rng3.sample(range(1,1<<62),M//2)
for k in initial: ot.put(k,k)
def miss_probes(table, count=1000):
    absent=[rng3.randrange(1<<62) for _ in range(count)]
    table.probes=0
    for k in absent: table.get(k)
    return table.probes/count
e3=[miss_probes(ot)]
for pairs in (2000,3000):
    for _ in range(pairs):
        k=rng3.randrange(1,1<<62); ot.put(k,k); ot.delete(k)
    e3.append(miss_probes(ot))
ot._rehash(ot.m); e3.append(miss_probes(ot))

# A2 analytical rows (key sequence is deterministic)
a2=[]
for m in (1000,1024,1009):
    tt=ChainedHashTable(m,resize=False,index_fn=lambda k,mm: k%mm)
    for k in range(100,2000001,100): tt.put(k,1)
    lengths=tt.chain_lengths()
    a2.append((f"k mod {m}",sum(x>0 for x in lengths),max(lengths),sum(x*(x+1)/2 for x in lengths)/20000))
tt=ChainedHashTable(1000,resize=False)
for k in range(100,2000001,100): tt.put(k,1)
lengths=tt.chain_lengths()
a2.append(("multiplicative m=1000",sum(x>0 for x in lengths),max(lengths),sum(x*(x+1)/2 for x in lengths)/20000))

with open("experiment_results.txt","w",encoding="utf-8") as f:
    f.write("LAB 5 EXPERIMENT RESULTS (seeded run; exact timings vary by machine)\\n\\n")
    f.write("A2: buckets used | longest chain | mean successful comparisons\\n")
    for row in a2: f.write(f"{row[0]}: {row[1]} | {row[2]} | {row[3]:.3f}\\n")
    f.write(f"\\nE1: resizes={e1[0]}, moves={e1[1]}, moves/insert={e1[2]:.4f}\\n")
    f.write("E3 miss probes: initial, after 2000 pairs, after 5000 total pairs, after rehash = "+", ".join(f"{v:.3f}" for v in e3)+"\\n")
    f.write("\\nD measured values (alpha, scheme, successful, unsuccessful)\\n")
    for i,a in enumerate(alphas):
        for s in schemes:
            f.write(f"{a:.2f}, {s}, {measured_s[s][i]:.3f}, {measured_u[s][i]:.3f}\\n")
    f.write("\\nTheory values at alpha 0.5, 0.7, 0.9\\n")
    for a in (.5,.7,.9):
        f.write(f"alpha={a}: chaining success={1+a/2:.3f}, chaining miss={a:.3f}; linear success={.5*(1+1/(1-a)):.3f}, linear miss={.5*(1+1/(1-a)**2):.3f}; uniform success={math.log(1/(1-a))/a:.3f}, uniform miss={1/(1-a):.3f}\\n")
print("Created B4_poisson.png, D2_probes_vs_alpha.png, E2_resize_spikes.png and experiment_results.txt")
print("E1:",e1)
print("E3:",e3)
