"""Worked solution for Lab 5: Hashing and Hash Tables.
Run: python lab5.py
Plots and a results report are generated in the current directory.
"""
import random, math, time
from collections import Counter

MASK64 = (1 << 64) - 1
GOLDEN64 = 0x9E3779B97F4A7C15
SECOND64 = 0xC2B2AE3D27D4EB4F
P61 = (1 << 61) - 1
EMPTY = None
DELETED = object()

def h_division(k, m):
    return k % m

def h_multiplication(k, bits):
    return (((k * GOLDEN64) & MASK64) >> (64 - bits))

def poly_hash(s, base=31, mod=(1 << 61) - 1):
    h = 0
    for ch in s:
        h = (h * base + ord(ch)) % mod
    return h

def sum_hash(s):
    return sum(ord(ch) for ch in s)

def fnv1a_32(data: bytes):
    h = 0x811C9DC5
    for b in data:
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h

def key_int(key):
    return key if isinstance(key, int) and key >= 0 else hash(key) & MASK64

class UniversalHash:
    def __init__(self, m, rng=None):
        rng = rng or random.Random()
        self.m, self.a, self.b = m, rng.randrange(1, P61), rng.randrange(0, P61)
    def __call__(self, k):
        return ((self.a * k + self.b) % P61) % self.m

class ChainedHashTable:
    def __init__(self, capacity=8, max_load=1.0, resize=True, index_fn=None):
        self.m = capacity
        self.buckets = [[] for _ in range(capacity)]
        self.n = 0
        self.max_load = max_load
        self.resize_enabled = resize
        self.index_fn = index_fn
        self.probes = self.moves = self.resizes = 0
    def _index(self, key):
        if self.index_fn:
            return self.index_fn(key, self.m)
        return (((key_int(key) * GOLDEN64) & MASK64) * self.m) >> 64
    def __len__(self): return self.n
    def load_factor(self): return self.n / self.m
    def get(self, key, default=None):
        for k, v in self.buckets[self._index(key)]:
            self.probes += 1
            if k == key: return v
        return default
    def __contains__(self, key):
        sentinel = object()
        return self.get(key, sentinel) is not sentinel
    def put(self, key, value):
        bucket = self.buckets[self._index(key)]
        for i, (k, _) in enumerate(bucket):
            self.probes += 1
            if k == key:
                bucket[i] = [key, value]
                return
        bucket.append([key, value]); self.n += 1
        if self.resize_enabled and self.n / self.m > self.max_load:
            self._resize(2 * self.m)
    def delete(self, key):
        bucket = self.buckets[self._index(key)]
        for i, (k, _) in enumerate(bucket):
            self.probes += 1
            if k == key:
                bucket.pop(i); self.n -= 1
                return True
        return False
    def _resize(self, new_m):
        old = list(self.items())
        self.m = new_m
        self.buckets = [[] for _ in range(new_m)]
        self.n = 0
        self.resizes += 1
        for k, v in old:
            self.buckets[self._index(k)].append([k, v])
            self.n += 1
            self.moves += 1
    def chain_lengths(self): return [len(b) for b in self.buckets]
    def items(self):
        for bucket in self.buckets:
            for k, v in bucket:
                yield k, v

class OpenHashTable:
    """Open addressing. Capacity is rounded up to a power of two."""
    def __init__(self, capacity=8, probing="linear", max_load=0.5, resize=True):
        bits = max(3, (capacity - 1).bit_length())
        self.bits, self.m = bits, 1 << bits
        self.keys = [EMPTY] * self.m
        self.vals = [None] * self.m
        self.n = self.tombs = 0
        self.probing = probing
        self.max_load = max_load
        self.resize_enabled = resize
        self.probes = self.moves = self.resizes = 0
    def __len__(self): return self.n
    def load_factor(self): return self.n / self.m
    def _h1(self, key):
        return ((key_int(key) * GOLDEN64) & MASK64) >> (64 - self.bits)
    def _h2(self, key):
        return ((((key_int(key) * SECOND64) & MASK64) >> (64 - self.bits)) | 1)
    def _probe_seq(self, key):
        h = self._h1(key)
        for i in range(self.m):
            if self.probing == "linear":
                offset = i
            elif self.probing == "quadratic":
                offset = i * (i + 1) // 2
            elif self.probing == "double":
                offset = i * self._h2(key)
            else:
                raise ValueError("unknown probing scheme")
            yield (h + offset) & (self.m - 1)
    def _find(self, key):
        first_deleted = None
        for j in self._probe_seq(key):
            self.probes += 1
            resident = self.keys[j]
            if resident is EMPTY:
                return None, (first_deleted if first_deleted is not None else j)
            if resident is DELETED:
                if first_deleted is None: first_deleted = j
            elif resident == key:
                return j, j
        return None, first_deleted
    def get(self, key, default=None):
        j, _ = self._find(key)
        return default if j is None else self.vals[j]
    def __contains__(self, key): return self._find(key)[0] is not None
    def put(self, key, value):
        if self.resize_enabled and (self.n + self.tombs + 1) / self.m > self.max_load:
            new_m = self.m * 2 if (self.n + 1) / self.m > self.max_load else self.m
            self._rehash(new_m)
        j, reusable = self._find(key)
        if j is not None:
            self.vals[j] = value
            return
        if reusable is None:
            if not self.resize_enabled: raise RuntimeError("hash table is full")
            self._rehash(self.m * 2)
            self.put(key, value)
            return
        if self.keys[reusable] is DELETED: self.tombs -= 1
        self.keys[reusable] = key
        self.vals[reusable] = value
        self.n += 1
    def delete(self, key):
        j, _ = self._find(key)
        if j is None: return False
        self.keys[j] = DELETED; self.vals[j] = None
        self.n -= 1; self.tombs += 1
        return True
    def _rehash(self, new_m):
        old = list(self.items())
        self.bits = max(3, (new_m - 1).bit_length())
        self.m = 1 << self.bits
        self.keys = [EMPTY] * self.m; self.vals = [None] * self.m
        self.n = self.tombs = 0; self.resizes += 1
        for k, v in old:
            self._insert_no_resize(k, v)
            self.moves += 1
    def _insert_no_resize(self, key, value):
        for j in self._probe_seq(key):
            if self.keys[j] is EMPTY:
                self.keys[j] = key; self.vals[j] = value; self.n += 1
                return
    def clusters(self):
        occ = [k is not EMPTY for k in self.keys]
        if all(occ): return [self.m]
        start = occ.index(False); runs=[]; cur=0
        for i in range(1, self.m + 1):
            if occ[(start+i) % self.m]: cur += 1
            elif cur:
                runs.append(cur); cur=0
        return runs
    def items(self):
        for k, v in zip(self.keys, self.vals):
            if k is not EMPTY and k is not DELETED:
                yield k, v

def _run_tests():
    def check(make, ops=4000, seed=1):
        rng=random.Random(seed); t=make(); ref={}
        for _ in range(ops):
            k=rng.choice([rng.randrange(300), f"k{rng.randrange(300)}"])
            r=rng.random()
            if r < .5:
                v=rng.random(); t.put(k,v); ref[k]=v
            elif r < .75:
                assert t.delete(k)==(k in ref)
                ref.pop(k,None)
            else: assert t.get(k)==ref.get(k)
        assert len(t)==len(ref) and dict(t.items())==ref
    tests = [
        ("Part A hash functions", lambda: (
            h_division(1234,100)==34 and
            0 <= h_multiplication(123456789,10) < 1024 and
            h_multiplication(100,10) != h_multiplication(200,10) and
            poly_hash("ab")==97*31+98 and poly_hash("listen")!=poly_hash("silent") and
            fnv1a_32(b"")==0x811C9DC5 and fnv1a_32(b"a")==0xE40C292C)),
        ("Part B chaining vs dict + resizing", lambda: (check(lambda: ChainedHashTable()) or True)),
        ("Part C probe sequences cover table", lambda: all(sorted(list(OpenHashTable(64,p,resize=False)._probe_seq(424242)))==list(range(64)) for p in ("linear","quadratic","double"))),
        ("Part C open addressing vs dict", lambda: all((check(lambda p=p: OpenHashTable(probing=p),seed=7) or True) for p in ("linear","quadratic","double"))),
        ("Part C tombstones", lambda: _test_tombstones()),
    ]
    for name, fn in tests:
        try:
            assert fn()
            print("PASS", name)
        except Exception as e:
            print("FAIL", name, repr(e))
            raise

def _test_tombstones():
    t=OpenHashTable(16,"linear",resize=False); home=t._h1(0)
    same=[k for k in range(1,5000) if t._h1(k)==home][:3]
    for k in same: t.put(k,k)
    t.delete(same[1])
    assert t.get(same[2])==same[2] and t.tombs==1
    return True

if __name__ == "__main__":
    _run_tests()
