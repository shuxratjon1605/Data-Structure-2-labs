# Lab 5: Hashing and Hash Tables — Worked Report

## Part A — Hash functions

### A1
Implemented `h_division`, `h_multiplication`, `poly_hash`, and `fnv1a_32` in `lab5.py`. The FNV-1a checks are:
- `fnv1a_32(b"") == 0x811C9DC5`
- `fnv1a_32(b"a") == 0xE40C292C`

### A2
Run `python experiments.py` to calculate the exact bucket statistics for the given sequence and save them to `experiment_results.txt`. Expected interpretation:
- `k mod 1000`: every key is divisible by 100, so only 10 buckets are used; each used bucket has 2,000 keys, giving a very long chain.
- `k mod 1024`: because the step size 100 shares a factor of 4 with 1024, only 256 different residues occur. The distribution is much less uniform than ideal.
- `k mod 1009`: 100 is relatively prime to 1009, so residues spread across all 1009 buckets; chain lengths are about 19–20.
- Multiplicative hashing spreads the sequential keys much better than the poor `k % 1000` choice.

For a chain of length L, a successful search takes on average `(L+1)/2` comparisons if all keys are equally likely and the keys are searched in the order represented by the chain.

### A3
The script implements the hash functions; the full random-word comparison can be run with the supplied classes and `sum_hash`. The exact statistics for a reproducible set of 20,000 distinct words are included in `experiment_results.txt`. The sum of characters is poor because anagrams and many different permutations have exactly the same sum, so it produces repeated hash values before bucket compression. Polynomial hashing and FNV-1a depend on character order and generally spread words more evenly. Python's built-in hash is randomized between interpreter runs, so its precise values and table statistics can vary.

## Part B — Separate chaining

### B1–B2
`ChainedHashTable` implements lookup, insertion/update, deletion, resize-by-doubling, probe counting, and move counting. A probe is counted for each stored key compared. Updating an existing key does not increase the table size.

### B3 — hand calculation
Insert `10, 22, 31, 4, 15, 28, 17, 88, 59` into 11 buckets using `k mod 11`:
- Bucket 0: `22, 88`
- Bucket 4: `4, 15, 59`
- Bucket 6: `28, 17`
- Bucket 9: `31`
- Bucket 10: `10`; all other buckets are empty.
- Load factor: `9/11 ≈ 0.818`.
- Exact mean successful comparisons: `(2·3/2 + 3·4/2 + 2·3/2 + 1 + 1)/9 = 14/9 ≈ 1.556`.
- Formula estimate: `1 + alpha/2 = 1 + (9/11)/2 ≈ 1.409`.

The measured average is higher than the formula estimate because the small example has uneven chain lengths.

### B4
`B4_poisson.png` compares observed chain-length counts with the Poisson prediction `m e^-1 / k!` for alpha = 1. Small differences are expected from random variation.

## Part C — Open addressing

### C1
Implemented linear probing, triangular-number quadratic probing, and double hashing. For a table of size `2^k`, linear probing visits slots in order. Triangular offsets `i(i+1)/2` cover every residue modulo a power of two; double hashing uses an odd step, which is relatively prime to `2^k`, so it visits every slot.

### C2
`_find` counts inspected slots and remembers the first tombstone while continuing to search for an existing key. Deletion writes `DELETED` rather than an empty slot, so a search does not stop prematurely at a deleted position. Insertion reuses tombstones and rehashes when the occupied-plus-tombstone load threshold is exceeded.

### C3 — CLRS hand trace
The table entries below are the final slot contents for slots 0 through 10. The probe counts count inspected slots, including the successful slot.

| Scheme | Slot 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | Total probes |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Linear | 22 | 88 | – | – | 4 | 15 | 28 | 17 | 59 | 31 | 10 | 16 |
| Quadratic | 22 | – | 88 | 17 | 4 | – | 28 | 59 | 15 | 31 | 10 | 23 |
| Double | 22 | – | 59 | 17 | 4 | 15 | 28 | 88 | – | 31 | 10 | 16 |

Per-key probes in insertion order `10, 22, 31, 4, 15, 28, 17, 88, 59`:
- Linear: `1, 1, 1, 1, 2, 1, 2, 2, 5`.
- Quadratic: `1, 1, 1, 1, 2, 1, 4, 9, 3`.
- Double hashing: `1, 1, 1, 1, 3, 1, 2, 3, 3`.

The quadratic formula for this paper exercise is `(h(k) + i + 3i²) mod 11`; the implementation's C1 triangular probing is a separate scheme.

### C4
If deleting key 15 simply made its slot empty, a later key in the same probe cluster could become unreachable: lookup stops at the first empty slot. A tombstone marks a slot as previously occupied, so lookup continues through it while insertion may reuse it.

## Part D — Load-factor experiments

`D2_probes_vs_alpha.png` plots successful and unsuccessful probes for chaining, linear, quadratic, and double hashing, together with theoretical curves. Exact measured values are written to `experiment_results.txt`; random-sample results can vary slightly by environment. The theoretical curves in the handout are for linear probing and uniform hashing (a useful approximation for double hashing); the chaining formulas are included as an additional reference.

### D3 answers
(a) Theory follows the broad trend. Measurements differ due to finite table size, random keys, and dependence among probe sequences.  
(b) Linear probing degrades fastest because primary clustering creates long contiguous runs; later operations are increasingly likely to encounter them.  
(c) Chaining remains relatively inexpensive at alpha = 0.95 because alpha is the average chain length, not the fraction of slots in one contiguous cluster. Under uniform hashing, unsuccessful searches average about alpha key comparisons and successful searches about `1 + alpha/2`.  
(d) A reasonable starting policy is chaining around alpha 1 or higher if memory allows, linear probing below about 0.7, and quadratic/double hashing around 0.7–0.8. The final threshold should be selected from measured workload performance.

## Part E — Resizing and tombstones

### E1
`experiment_results.txt` records the number of resizes, total moved entries, and moves per insertion for 100,000 insertions. With doubling, each entry is moved only at geometrically increasing resize events; total moves are linear in the number of insertions and the handout's bound is fewer than `2n` moves.

### E2
`E2_resize_spikes.png` shows the slowest insertion in each block of 500. Spikes occur at resize boundaries because the table must allocate a larger bucket array and reinsert all existing entries. Amortised O(1) means average insertion cost over a long sequence is constant; it does not promise that every individual insertion is constant-time.

### E3
The results file gives unsuccessful-search probe counts initially, after 2,000 insert-delete pairs, after 5,000 total pairs, and after rehashing. Insert-delete churn leaves tombstones behind, so unsuccessful searches can become slower even if the number of live keys stays about the same. Rehashing reinserts live keys and removes tombstones, reducing this overhead.

## Files and execution
1. Run `python lab5.py` to run the five built-in checks.
2. Run `python experiments.py` to generate the three plots and the numerical results file.
3. Submit `lab5.py`, `experiments.py`, the three PNG plots, and `experiment_results.txt`.

**Important:** the handout's Part A3 and Part D results are random experiments; report the output from your own run rather than treating any one random sample as a universal constant.


## Review note / scope
This solution covers the required Parts A–E and the three required plots. The optional Robin Hood/hash-flooding bonus challenge is not implemented. For A3 and D, numerical results are generated by the included experiment script and can vary with the random sample and Python hash seed. Run the scripts in the same folder to regenerate results and plots.
